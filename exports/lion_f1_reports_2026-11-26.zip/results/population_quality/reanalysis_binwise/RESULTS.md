# Direct binwise correctness reanalysis

No new generation, inference or classifier training. Frozen score bins, natural reference, accepted outputs and test F1 are unchanged. Under shared annotation mechanism and full within-bin input-distribution equality, total expectation gives pi_r = sum_j q_rj theta_j. Calibration tails are .025/J; each mass endpoint receives .025/(2*11*J). Greedy bounded-simplex minimization was independently verified with scipy.optimize.linprog for every arm, along with all requested limiting cases.

**Coverage caveat:** Natural inputs were deduplicated and shuffled into disjoint design/reference partitions without replacement. Deduplication couples observations; one example per sentence and disjoint IDs alone do not establish IID Bernoulli trials for an external task population. The original implementation assumed independent natural sentences, but did not justify an exact binomial sampling model after this selection. These computations retain that conditional/nominal interpretation; unconditional exact task-population 95% coverage is not established. A finite-population justification would require specifying the target and sampling design rather than silently changing P0. All PASS/FAIL entries below are nominal and conditional on the sampling and within-bin assumptions.

| Bin | Score range | Natural n | Correct k | Correctness | Lower L_j |
|---|---|---:|---:|---:|---:|
| 0 | (-inf, 8.121673583984375] | 2460 | 2398 | 97.480% | 96.548% |
| 1 | (8.121673583984375, 8.627094841003418] | 2465 | 2391 | 96.998% | 95.997% |
| 2 | (8.627094841003418, 9.03665599822998] | 2842 | 2754 | 96.904% | 95.967% |
| 3 | (9.03665599822998, 9.491767311096192] | 2548 | 2470 | 96.939% | 95.948% |
| 4 | (9.491767311096192, inf] | 2746 | 2695 | 98.143% | 97.372% |

| Arm | Accepted | Plug-in | New lower | Margin pp | Conditional check | Previous lower | Old G |
|---|---:|---:|---:|---:|---|---:|---:|
| uniform | 1279 | 97.337% | 96.357% | +1.357 | PASS | 0.09554% | 56.216% |
| lambda0.001 | 1911 | 97.338% | 96.366% | +1.366 | PASS | 0.02417% | 70.696% |
| lambda0.01 | 1977 | 97.339% | 96.367% | +1.367 | PASS | 0.09696% | 71.674% |
| lambda0.1 | 1469 | 97.333% | 96.356% | +1.356 | PASS | 0.04092% | 61.879% |
| greedy | 1847 | 97.337% | 96.366% | +1.366 | PASS | 0.00023% | 69.681% |
| nearby20 | 28 | 97.396% | 96.075% | +1.075 | PASS | 1.33065% | 0.000% |
| nearby50 | 147 | 97.208% | 96.093% | +1.093 | PASS | 73.15377% | 0.000% |
| nearby70 | 236 | 97.235% | 96.147% | +1.147 | PASS | 83.39252% | 0.000% |
| sentence20 | 38 | 97.212% | 96.002% | +1.002 | PASS | 14.27289% | 0.000% |
| sentence50 | 251 | 97.170% | 96.099% | +1.099 | PASS | 40.15511% | 0.000% |
| sentence70 | 653 | 97.287% | 96.283% | +1.283 | PASS | 0.59093% | 14.242% |

Accepted bin proportions and optimizing masses: accepted_bins.csv. arm_results.csv includes unchanged per-dataset F1 means, seed SDs and paired improvements. correlations.csv includes both scopes and all old/new metrics. audit.json records provenance; mathematical_checks.json records actual LP and limiting-case checks.

| Arm | Empirical quality | Calibration uncertainty loss pp | Mass uncertainty loss pp |
|---|---:|---:|---:|
| uniform | 97.337% | 0.946 | 0.034 |
| lambda0.001 | 97.338% | 0.946 | 0.026 |
| lambda0.01 | 97.339% | 0.946 | 0.027 |
| lambda0.1 | 97.333% | 0.947 | 0.031 |
| greedy | 97.337% | 0.947 | 0.024 |
| nearby20 | 97.396% | 0.909 | 0.412 |
| nearby50 | 97.208% | 0.943 | 0.172 |
| nearby70 | 97.235% | 0.938 | 0.149 |
| sentence20 | 97.212% | 0.941 | 0.269 |
| sentence50 | 97.170% | 0.952 | 0.119 |
| sentence70 | 97.287% | 0.949 | 0.056 |

All five bin-specific correctness lower bounds exceed 95%; consequently every feasible mixture passes the numerical threshold. Empirical quality differs little across arms (about 97.17–97.40%). The mass-uncertainty loss is about 0.024–0.034 percentage points for the five refinement arms, versus up to 0.412 points for the 28-example window-20 arm. The larger differences in the rigorous bounds therefore substantially reflect accepted-sample uncertainty, as well as bin composition. No old reverse-ratio penalty applies when generated mass avoids a natural bin. Neither old/new bounds nor their maximum are used to select or retrain models.

| Arm | Few-NERD native delta pp | CoNLL delta pp | WNUT delta pp | WikiANN delta pp |
|---|---:|---:|---:|---:|
| uniform | +0.072 | +0.479 | +0.915 | +0.127 |
| lambda0.001 | -0.097 | +0.341 | +1.165 | +0.269 |
| lambda0.01 | -0.151 | +0.403 | +1.530 | +0.370 |
| lambda0.1 | +0.095 | +0.159 | +1.580 | +0.087 |
| greedy | -0.049 | +0.831 | +1.368 | +0.573 |
| nearby20 | -0.033 | +0.135 | -0.200 | -0.030 |
| nearby50 | -0.083 | +0.039 | +0.317 | -0.032 |
| nearby70 | -0.186 | -0.234 | +0.333 | +0.151 |
| sentence20 | -0.001 | +0.091 | -0.171 | -0.018 |
| sentence50 | -0.110 | -0.126 | +0.194 | -0.072 |
| sentence70 | -0.101 | -0.317 | +1.068 | -0.250 |

Correlations across all_11; cells are Pearson / Spearman.

| Dataset | New lower | New plug-in | Previous worst-ratio lower | Old G |
|---|---:|---:|---:|---:|
| fewnerd | +0.163 / -0.182 | +0.322 / +0.164 | -0.495 / -0.418 | +0.257 / +0.019 |
| conll2003 | +0.558 / +0.618 | +0.566 / +0.636 | -0.520 / -0.782 | +0.765 / +0.706 |
| wnut | +0.951 / +0.864 | +0.473 / +0.327 | -0.477 / -0.700 | +0.885 / +0.877 |
| wikiann | +0.576 / +0.700 | +0.419 / +0.527 | -0.218 / -0.555 | +0.743 / +0.686 |

Correlations across refinement_5; cells are Pearson / Spearman.

| Dataset | New lower | New plug-in | Previous worst-ratio lower | Old G |
|---|---:|---:|---:|---:|
| fewnerd | -0.955 / -1.000 | -0.810 / -0.900 | +0.024 / -0.200 | -0.902 / -0.900 |
| conll2003 | +0.482 / +0.200 | +0.408 / +0.100 | -0.335 / -0.200 | +0.232 / -0.100 |
| wnut | +0.136 / -0.100 | -0.341 / -0.300 | -0.194 / +0.100 | +0.479 / +0.300 |
| wikiann | +0.820 / +0.700 | +0.499 / +0.400 | -0.450 / -0.300 | +0.725 / +0.600 |

Correlations are descriptive. Across all arms, the new lower bound has high Pearson association on WNUT (+0.952), while native Few-NERD is weak (+0.163). Within refinement alone the native correlation reverses strongly (-0.955). The new bound therefore does not uniformly rank downstream usefulness better than the older metrics; its WNUT association also reflects accepted-sample-size uncertainty. Certificates remain separate and conditional.
