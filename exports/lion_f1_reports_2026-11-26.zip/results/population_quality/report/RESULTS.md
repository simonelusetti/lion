# Binned population-correctness diagnostic

Small generation budget: 20,000 IID proposal trajectories per arm; same 2,400 original student sentences, fixed full-data scorer, three seeds and equal training budgets. Certification is diagnostic and never blocks training. Natural bin design is frozen before reference correctness/frequencies or downstream evaluation.

The conditional certificate assumes identical natural/generated input distributions within each bin, matching support, shared annotation mechanism, and independent observations. Bin counts do not establish these assumptions. The score is parallel masked-reconstruction NLL, not a generator density. Historical guided lambda rules retain their original finite-pool policy.

| Arm | Accepted | M upper | Quality lower | Plug-in quality | Check | Native F1 | Delta pp |
|---|---:|---:|---:|---:|---|---:|---:|
| uniform | 1279 | 184.0189114567669 | 0.0010 | 0.0309 | FAIL | 58.67 | +0.07 |
| lambda0.001 | 1911 | 366.0125723748168 | 0.0002 | 0.0108 | FAIL | 58.50 | -0.10 |
| lambda0.01 | 1977 | 182.66415189510286 | 0.0010 | 0.0204 | FAIL | 58.45 | -0.15 |
| lambda0.1 | 1469 | 281.24921583423054 | 0.0004 | 0.0182 | FAIL | 58.70 | +0.09 |
| greedy | 1847 | 3718.483545482042 | 0.0000 | 0.0021 | FAIL | 58.55 | -0.05 |
| nearby20 | 28 | 49.00356174320112 | 0.0133 | 0.9209 | FAIL | 58.57 | -0.03 |
| nearby50 | 147 | 3.4474046735915738 | 0.7315 | 0.9347 | FAIL | 58.52 | -0.08 |
| nearby70 | 236 | 2.539553292163042 | 0.8339 | 0.9409 | FAIL | 58.41 | -0.19 |
| sentence20 | 38 | 13.946723690701399 | 0.1427 | 0.9278 | FAIL | 58.60 | -0.00 |
| sentence50 | 251 | 6.947236518944341 | 0.4016 | 0.8379 | FAIL | 58.49 | -0.11 |
| sentence70 | 653 | 73.80983308131158 | 0.0059 | 0.1340 | FAIL | 58.50 | -0.10 |

Full per-seed classification results: ../test/per_seed.csv. All dataset means, seed SDs, paired improvements and quality numbers: arm_results.csv. Pearson/Spearman comparisons for all eleven arms and the refinement subset: correlations.csv. Undefined correlations retain their reason. Exact bin counts and intervals: ../diagnostic/bin_counts.csv; inspect zero lower endpoints for collapsed bounds. Independence audit: ../prepare/independence_audit.json.

Old G uses the historical fixed 0.028 error reference and empirical acceptance; it remains a descriptive ideal-sampler comparator. Neither quality lower bounds nor correlations verify the labels of individual augmentations.

Total wall-clock time: 1.73 hours.
