# Within-bin NLL distribution comparison

Saved natural and accepted-output scores only; five existing frozen bins. Adopt IID sampling as a working assumption. No generation, rescoring, fitting, new annotations, or bin changes. Bin IDs below are 1–5; CSV bin IDs are 0–4.

DKW–Massart: P(||Fhat−F||∞ > ε) ≤ 2 exp(−2nε²). There are 60 CDFs, so δ=0.0008333333. Each natural CDF is counted once. Conditional on positive sample counts, apply DKW to each CDF, then union bound and reverse triangle inequality: D_true ≥ max(0,D_emp−ε_n−ε_m). This yields simultaneous 95% lower bounds and at most 5% family-wide false refutation under the working sampling assumptions. Independence between arms or confidence events is not required. Exact tied score values are retained. [Massart (1990)](https://doi.org/10.1214/aop/1176990746).

| Arm | Accepted | Refuted bins | Untestable bins |
|---|---:|---|---|
| uniform | 1279 | 1, 3 | none |
| lambda0.001 | 1911 | 1 | none |
| lambda0.01 | 1977 | 1 | none |
| lambda0.1 | 1469 | 1 | none |
| greedy | 1847 | 1, 2, 3 | none |
| nearby20 | 28 | none | none |
| nearby50 | 147 | none | none |
| nearby70 | 236 | none | none |
| sentence20 | 38 | none | none |
| sentence50 | 251 | none | none |
| sentence70 | 653 | 1 | none |

| Arm | Bin | Natural n | Generated n | KS distance | Simultaneous lower bound | Outcome |
|---|---:|---:|---:|---:|---:|---|
| uniform | 1 | 2460 | 901 | 0.20096 | 0.09547 | refuted |
| uniform | 2 | 2465 | 269 | 0.13065 | 0.00000 | inconclusive |
| uniform | 3 | 2842 | 84 | 0.26067 | 0.00843 | refuted |
| uniform | 4 | 2548 | 17 | 0.11917 | 0.00000 | inconclusive |
| uniform | 5 | 2746 | 8 | 0.55863 | 0.00000 | inconclusive |
| lambda0.001 | 1 | 2460 | 1363 | 0.18196 | 0.08876 | refuted |
| lambda0.001 | 2 | 2465 | 382 | 0.13902 | 0.00000 | inconclusive |
| lambda0.001 | 3 | 2842 | 129 | 0.20557 | 0.00000 | inconclusive |
| lambda0.001 | 4 | 2548 | 30 | 0.20194 | 0.00000 | inconclusive |
| lambda0.001 | 5 | 2746 | 7 | 0.41213 | 0.00000 | inconclusive |
| lambda0.01 | 1 | 2460 | 1408 | 0.19581 | 0.10346 | refuted |
| lambda0.01 | 2 | 2465 | 394 | 0.13187 | 0.00000 | inconclusive |
| lambda0.01 | 3 | 2842 | 135 | 0.14333 | 0.00000 | inconclusive |
| lambda0.01 | 4 | 2548 | 30 | 0.15534 | 0.00000 | inconclusive |
| lambda0.01 | 5 | 2746 | 10 | 0.40568 | 0.00000 | inconclusive |
| lambda0.1 | 1 | 2460 | 1028 | 0.19265 | 0.09135 | refuted |
| lambda0.1 | 2 | 2465 | 307 | 0.14431 | 0.00000 | inconclusive |
| lambda0.1 | 3 | 2842 | 102 | 0.19951 | 0.00000 | inconclusive |
| lambda0.1 | 4 | 2548 | 25 | 0.08086 | 0.00000 | inconclusive |
| lambda0.1 | 5 | 2746 | 7 | 0.56971 | 0.00000 | inconclusive |
| greedy | 1 | 2460 | 1321 | 0.18792 | 0.09387 | refuted |
| greedy | 2 | 2465 | 370 | 0.15035 | 0.00806 | refuted |
| greedy | 3 | 2842 | 117 | 0.23215 | 0.01276 | refuted |
| greedy | 4 | 2548 | 36 | 0.17587 | 0.00000 | inconclusive |
| greedy | 5 | 2746 | 3 | 0.40568 | 0.00000 | inconclusive |
| nearby20 | 1 | 2460 | 3 | 0.50447 | 0.00000 | inconclusive |
| nearby20 | 2 | 2465 | 8 | 0.33367 | 0.00000 | inconclusive |
| nearby20 | 3 | 2842 | 4 | 0.20989 | 0.00000 | inconclusive |
| nearby20 | 4 | 2548 | 4 | 0.44349 | 0.00000 | inconclusive |
| nearby20 | 5 | 2746 | 9 | 0.24982 | 0.00000 | inconclusive |
| nearby50 | 1 | 2460 | 21 | 0.29994 | 0.00000 | inconclusive |
| nearby50 | 2 | 2465 | 44 | 0.11278 | 0.00000 | inconclusive |
| nearby50 | 3 | 2842 | 26 | 0.16186 | 0.00000 | inconclusive |
| nearby50 | 4 | 2548 | 34 | 0.16292 | 0.00000 | inconclusive |
| nearby50 | 5 | 2746 | 22 | 0.25177 | 0.00000 | inconclusive |
| nearby70 | 1 | 2460 | 40 | 0.20244 | 0.00000 | inconclusive |
| nearby70 | 2 | 2465 | 67 | 0.08473 | 0.00000 | inconclusive |
| nearby70 | 3 | 2842 | 43 | 0.13634 | 0.00000 | inconclusive |
| nearby70 | 4 | 2548 | 48 | 0.07401 | 0.00000 | inconclusive |
| nearby70 | 5 | 2746 | 38 | 0.20173 | 0.00000 | inconclusive |
| sentence20 | 1 | 2460 | 5 | 0.53659 | 0.00000 | inconclusive |
| sentence20 | 2 | 2465 | 12 | 0.14182 | 0.00000 | inconclusive |
| sentence20 | 3 | 2842 | 7 | 0.30718 | 0.00000 | inconclusive |
| sentence20 | 4 | 2548 | 8 | 0.44780 | 0.00000 | inconclusive |
| sentence20 | 5 | 2746 | 6 | 0.39366 | 0.00000 | inconclusive |
| sentence50 | 1 | 2460 | 57 | 0.18524 | 0.00000 | inconclusive |
| sentence50 | 2 | 2465 | 83 | 0.05651 | 0.00000 | inconclusive |
| sentence50 | 3 | 2842 | 51 | 0.21445 | 0.00000 | inconclusive |
| sentence50 | 4 | 2548 | 40 | 0.15043 | 0.00000 | inconclusive |
| sentence50 | 5 | 2746 | 20 | 0.27050 | 0.00000 | inconclusive |
| sentence70 | 1 | 2460 | 389 | 0.17185 | 0.03205 | refuted |
| sentence70 | 2 | 2465 | 149 | 0.12192 | 0.00000 | inconclusive |
| sentence70 | 3 | 2842 | 74 | 0.14367 | 0.00000 | inconclusive |
| sentence70 | 4 | 2548 | 32 | 0.13329 | 0.00000 | inconclusive |
| sentence70 | 5 | 2746 | 9 | 0.26014 | 0.00000 | inconclusive |

Highest-NLL bin: φ > 9.491767. Quantiles for every bin are in score_quantiles.csv.

| Population | n | Median | p90 | p95 | p99 | Maximum |
|---|---:|---:|---:|---:|---:|---:|
| natural | 2746 | 9.86632 | 10.64739 | 11.01469 | 12.14466 | 15.16117 |
| uniform | 8 | 9.68605 | 9.80280 | 9.80401 | 9.80498 | 9.80522 |
| lambda0.001 | 7 | 9.73945 | 9.87617 | 9.92683 | 9.96735 | 9.97748 |
| lambda0.01 | 10 | 9.72524 | 9.95698 | 9.96723 | 9.97543 | 9.97748 |
| lambda0.1 | 7 | 9.53787 | 9.80658 | 9.80759 | 9.80841 | 9.80861 |
| greedy | 3 | 9.68897 | 9.91978 | 9.94863 | 9.97171 | 9.97748 |
| nearby20 | 9 | 9.72263 | 10.16353 | 10.18142 | 10.19573 | 10.19931 |
| nearby50 | 22 | 9.77464 | 10.06270 | 10.19768 | 10.20800 | 10.20887 |
| nearby70 | 38 | 9.79515 | 10.12936 | 10.69198 | 11.11421 | 11.33951 |
| sentence20 | 6 | 9.80419 | 9.97725 | 9.98571 | 9.99247 | 9.99416 |
| sentence50 | 20 | 9.73875 | 10.28118 | 10.30720 | 10.36381 | 10.37797 |
| sentence70 | 9 | 9.77257 | 10.25977 | 10.35623 | 10.43341 | 10.45270 |

Positive lower bounds establish score mismatch hidden inside frozen bins under the working assumptions. Empty and low-count generated bins can be inconclusive because their DKW radii are large. Refutation is of full within-bin input equality through a necessary score consequence; it does not directly test correctness transfer, pseudo-label accuracy, or downstream usefulness. Non-refutation does not validate the assumption.

Machine-readable results: pairs.csv, arms.csv, score_quantiles.csv. Full exact empirical CDFs: empirical_cdfs.pt. Allocation and simultaneous argument: method.json.
