# Over-contextualization diagnostics

Protocol and baseline inventory: [plan.md](plan.md). Sampling caps are a computational budget, not the full-data baseline training population. Diagnostic readouts are refitted on identical focal samples, with three classifier seeds. The focal sample is uniform over sentences and changes token weighting relative to the full corpus. Seed spread describes optimization variation conditional on one fixed sample, not sampling uncertainty or confidence intervals.

## Availability in the frozen diagnostic inventory

This records availability when this suite was launched. Later baseline repairs do not expand these diagnostic samples or change their recorded results.

- wikiann: unavailable token cache; baseline statuses: failed. Skipped throughout.
- wnut: unavailable token cache; baseline statuses: failed. Skipped throughout.

Genre Z is recovered from raw cached UD sentence IDs, rather than invented. Other native tasks have no retained usable genre/source variable; the shared NER comparison uses dataset identity only. [inventory.json](inventory.json) records native document overlap and exact label sets. Metadata alignment is checked against cached token IDs before encoding.

## Actual sampling

| dataset | split | sentences | focals |
|---|---|---|---|
| fewnerd | train | 2048 | 4096 |
| fewnerd | validation | 512 | 1023 |
| fewnerd | test | 1024 | 2047 |
| conll2003 | train | 2048 | 4061 |
| conll2003 | validation | 512 | 1022 |
| conll2003 | test | 1024 | 2043 |
| ud_upos | train | 2048 | 4017 |
| ud_upos | validation | 512 | 998 |
| ud_upos | test | 1024 | 1971 |
| ud_deprel | train | 2048 | 4017 |
| ud_deprel | validation | 512 | 998 |
| ud_deprel | test | 1024 | 1971 |
| ud_discourse | train | 8192 | 16309 |
| ud_discourse | validation | 1575 | 3138 |
| ud_discourse | test | 1464 | 2916 |
| conll2000 | train | 2048 | 4094 |
| conll2000 | validation | 512 | 1024 |
| conll2000 | test | 1024 | 2047 |

## E1: Three views

**Measurement.** Token classification on identical sampled focal positions; full-training lexical statistics define bins.

Measured datasets: conll2000, conll2003, fewnerd, ner_shared, ud_deprel, ud_discourse, ud_upos.

Recorded 63 seed-level conditions. [Scores](e1/scores.csv), [seed summaries](e1/summary.csv).

| dataset | view | seeds | accuracy_mean | accuracy_std | macro_f1_mean | macro_f1_std |
|---|---|---|---|---|---|---|
| fewnerd | full | 3 | 0.9046 | 0.0020 | 0.5985 | 0.0092 |
| fewnerd | word_only | 3 | 0.8596 | 0.0012 | 0.3161 | 0.0057 |
| fewnerd | context_only | 3 | 0.8727 | 0.0050 | 0.5385 | 0.0183 |
| conll2003 | full | 3 | 0.8957 | 0.0013 | 0.5795 | 0.0121 |
| conll2003 | word_only | 3 | 0.8517 | 0.0008 | 0.4118 | 0.0026 |
| conll2003 | context_only | 3 | 0.8757 | 0.0010 | 0.5022 | 0.0109 |
| ud_upos | full | 3 | 0.7463 | 0.0018 | 0.6549 | 0.0048 |
| ud_upos | word_only | 3 | 0.7619 | 0.0026 | 0.6955 | 0.0085 |
| ud_upos | context_only | 3 | 0.5466 | 0.0086 | 0.4637 | 0.0075 |
| ud_deprel | full | 3 | 0.6482 | 0.0053 | 0.3249 | 0.0133 |
| ud_deprel | word_only | 3 | 0.6071 | 0.0016 | 0.2713 | 0.0056 |
| ud_deprel | context_only | 3 | 0.5180 | 0.0032 | 0.2585 | 0.0047 |
| ud_discourse | full | 3 | 0.2466 | 0.0015 | 0.1989 | 0.0064 |
| ud_discourse | word_only | 3 | 0.1571 | 0.0069 | 0.0666 | 0.0030 |
| ud_discourse | context_only | 3 | 0.2194 | 0.0036 | 0.1674 | 0.0060 |
| conll2000 | full | 3 | 0.8468 | 0.0040 | 0.2921 | 0.0009 |
| conll2000 | word_only | 3 | 0.7554 | 0.0057 | 0.2325 | 0.0088 |
| conll2000 | context_only | 3 | 0.8010 | 0.0010 | 0.2712 | 0.0034 |
| ner_shared | full | 3 | 0.9301 | 0.0017 | 0.7929 | 0.0067 |
| ner_shared | word_only | 3 | 0.9048 | 0.0012 | 0.6784 | 0.0041 |
| ner_shared | context_only | 3 | 0.8999 | 0.0037 | 0.7365 | 0.0049 |

**Measured directional contrasts.** Positive values follow the directional prediction named in each contrast (E4 instead records magnitudes without a preferred sign).

| dataset | claim | seeds | value_mean | value_std |
|---|---|---|---|---|
| fewnerd | full_minus_word_accuracy | 3 | 0.0449 | 0.0008 |
| conll2003 | full_minus_word_accuracy | 3 | 0.0441 | 0.0005 |
| ud_upos | full_minus_word_accuracy | 3 | -0.0156 | 0.0033 |
| ud_deprel | full_minus_word_accuracy | 3 | 0.0411 | 0.0059 |
| ud_discourse | full_minus_word_accuracy | 3 | 0.0895 | 0.0083 |
| conll2000 | full_minus_word_accuracy | 3 | 0.0914 | 0.0088 |
| ner_shared | full_minus_word_accuracy | 3 | 0.0252 | 0.0012 |
| fewnerd | ambiguous_minus_unambiguous_context_gain | 3 | 0.1296 | 0.0052 |
| conll2003 | ambiguous_minus_unambiguous_context_gain | 3 | 0.2029 | 0.0312 |
| ud_upos | ambiguous_minus_unambiguous_context_gain | 3 | 0.3192 | 0.0135 |
| ud_deprel | ambiguous_minus_unambiguous_context_gain | 3 | 0.1104 | 0.0138 |
| ud_discourse | ambiguous_minus_unambiguous_context_gain | 3 | -0.0414 | 0.0099 |
| conll2000 | ambiguous_minus_unambiguous_context_gain | 3 | 0.1880 | 0.0273 |
| ner_shared | ambiguous_minus_unambiguous_context_gain | 3 | 0.1471 | 0.0232 |
| fewnerd | rare_minus_frequent_context_gain | 3 | 0.2346 | 0.0222 |
| conll2003 | rare_minus_frequent_context_gain | 3 | 0.0915 | 0.0068 |
| ud_upos | rare_minus_frequent_context_gain | 3 | 0.0142 | 0.0186 |
| ud_deprel | rare_minus_frequent_context_gain | 3 | 0.0471 | 0.0144 |
| ud_discourse | rare_minus_frequent_context_gain | 3 | 0.0149 | 0.0129 |
| conll2000 | rare_minus_frequent_context_gain | 3 | 0.1114 | 0.0247 |
| ner_shared | rare_minus_frequent_context_gain | 3 | 0.1290 | 0.0117 |

**Directional claim assessment (descriptive):** 19 dataset/claim contrasts have the predicted positive sign in all three seeds; 2 have the opposite sign in all three seeds; 0 are mixed, tied, or incomplete. Consistent positive signs support the stated directional prediction on this fixed sample; opposite signs contradict that prediction on this sample. These counts are not significance tests or causal conclusions.

Frequency/ambiguity concentration: [gains](e1/gain_summary.csv); [per-label scores](e1/per_label.csv).

![Three views](e1/scores.png)

**Interpretation.** Differences between separately trained readouts measure the predictive value of these views. They do not identify spurious context or a causal effect of nuisance Z.

These tables provide diagnostic evidence; support or contradiction of the claimed ordering must be assessed across datasets, seed spread, and reported support counts. A universal causal conclusion is inconclusive from these observational diagnostics alone.

## E2: Masking and lexical distributions

**Measurement.** KL from empirical training label distributions to held-out mean predictions, occurrence KL, ECE and Brier score.

Measured datasets: conll2000, conll2003, fewnerd, ud_deprel, ud_discourse, ud_upos.

Recorded 36 seed-level conditions. [Scores](e2/scores.csv), [seed summaries](e2/summary.csv).

| dataset | view | seeds | type_mean_kl_mean | type_mean_kl_std | occurrence_kl_mean | occurrence_kl_std | ece_mean | ece_std |
|---|---|---|---|---|---|---|---|---|
| fewnerd | trained_word_only | 3 | 0.2718 | 0.0061 | 0.1283 | 0.0033 | 0.0227 | 0.0042 |
| fewnerd | full_on_word_only | 3 | 0.8785 | 0.0101 | 0.5680 | 0.0162 | 0.1432 | 0.0207 |
| conll2003 | trained_word_only | 3 | 0.8459 | 0.0324 | 0.3043 | 0.0131 | 0.0391 | 0.0043 |
| conll2003 | full_on_word_only | 3 | 2.8811 | 0.1631 | 1.0216 | 0.0481 | 0.1157 | 0.0109 |
| ud_upos | trained_word_only | 3 | 0.4884 | 0.0052 | 0.3406 | 0.0047 | 0.0358 | 0.0070 |
| ud_upos | full_on_word_only | 3 | 2.0213 | 0.0653 | 2.0582 | 0.0854 | 0.2567 | 0.0502 |
| ud_deprel | trained_word_only | 3 | 0.8924 | 0.0057 | 0.6526 | 0.0047 | 0.0314 | 0.0016 |
| ud_deprel | full_on_word_only | 3 | 2.9247 | 0.1587 | 2.6396 | 0.1384 | 0.2099 | 0.0284 |
| ud_discourse | trained_word_only | 3 | 0.6732 | 0.0314 | 0.4856 | 0.0265 | 0.0331 | 0.0131 |
| ud_discourse | full_on_word_only | 3 | 1.7862 | 0.0567 | 1.6318 | 0.0523 | 0.2224 | 0.0200 |
| conll2000 | trained_word_only | 3 | 0.3362 | 0.0118 | 0.1875 | 0.0071 | 0.0273 | 0.0005 |
| conll2000 | full_on_word_only | 3 | 2.0845 | 0.0826 | 2.0215 | 0.0538 | 0.3130 | 0.0344 |

**Measured directional contrasts.** Positive values follow the directional prediction named in each contrast (E4 instead records magnitudes without a preferred sign).

| dataset | claim | seeds | value_mean | value_std |
|---|---|---|---|---|
| fewnerd | shifted_minus_matched_KL | 3 | 0.6067 | 0.0160 |
| conll2003 | shifted_minus_matched_KL | 3 | 2.0352 | 0.1510 |
| ud_upos | shifted_minus_matched_KL | 3 | 1.5329 | 0.0703 |
| ud_deprel | shifted_minus_matched_KL | 3 | 2.0323 | 0.1640 |
| ud_discourse | shifted_minus_matched_KL | 3 | 1.1129 | 0.0594 |
| conll2000 | shifted_minus_matched_KL | 3 | 1.7482 | 0.0742 |

**Directional claim assessment (descriptive):** 6 dataset/claim contrasts have the predicted positive sign in all three seeds; 0 have the opposite sign in all three seeds; 0 are mixed, tied, or incomplete. Consistent positive signs support the stated directional prediction on this fixed sample; opposite signs contradict that prediction on this sample. These counts are not significance tests or causal conclusions.

![Masking and lexical distributions](e2/kl.png)

**Interpretation.** A lower KL for the mask-trained classifier is consistent with adaptation to masking. It does not establish P(Y|X_S): finite sampled training, model fit, position and mask length can all affect the result. Unseen or unsupported ambiguous types are not evaluated.

These tables provide diagnostic evidence; support or contradiction of the claimed ordering must be assessed across datasets, seed spread, and reported support counts. A universal causal conclusion is inconclusive from these observational diagnostics alone.

Skipped cells: 0. [Reasons and supports](e2/skips.csv).

## E3: Linear nuisance readability

**Measurement.** Class-balanced linear Z probes trained independently within each label; chance is 1 / eligible domain count.

Measured datasets: ner_shared, ud_deprel, ud_discourse, ud_upos.

Recorded 288 seed-level conditions. [Scores](e3/scores.csv), [seed summaries](e3/summary.csv).

| dataset | label | view | seeds | balanced_accuracy_mean | balanced_accuracy_std | above_chance_mean | above_chance_std |
|---|---|---|---|---|---|---|---|
| ud_upos | ADJ | full | 3 | 0.5286 | 0.0189 | 0.0286 | 0.0189 |
| ud_upos | ADJ | word_only | 3 | 0.5661 | 0.0532 | 0.0661 | 0.0532 |
| ud_upos | ADJ | context_only | 3 | 0.5686 | 0.0518 | 0.0686 | 0.0518 |
| ud_upos | ADP | full | 3 | 0.3043 | 0.0224 | 0.1043 | 0.0224 |
| ud_upos | ADP | word_only | 3 | 0.1998 | 0.0269 | -0.0002 | 0.0269 |
| ud_upos | ADP | context_only | 3 | 0.2959 | 0.0442 | 0.0959 | 0.0442 |
| ud_upos | AUX | full | 3 | 0.4834 | 0.0298 | 0.1501 | 0.0298 |
| ud_upos | AUX | word_only | 3 | 0.3635 | 0.0246 | 0.0301 | 0.0246 |
| ud_upos | AUX | context_only | 3 | 0.4112 | 0.0619 | 0.0778 | 0.0619 |
| ud_upos | DET | full | 3 | 0.3872 | 0.0359 | 0.1872 | 0.0359 |
| ud_upos | DET | word_only | 3 | 0.2190 | 0.0432 | 0.0190 | 0.0432 |
| ud_upos | DET | context_only | 3 | 0.3800 | 0.0189 | 0.1800 | 0.0189 |
| ud_upos | NOUN | full | 3 | 0.3291 | 0.0043 | 0.1291 | 0.0043 |
| ud_upos | NOUN | word_only | 3 | 0.2622 | 0.0063 | 0.0622 | 0.0063 |
| ud_upos | NOUN | context_only | 3 | 0.2794 | 0.0055 | 0.0794 | 0.0055 |
| ud_upos | PRON | full | 3 | 0.3056 | 0.0236 | 0.0556 | 0.0236 |
| ud_upos | PRON | word_only | 3 | 0.2410 | 0.0149 | -0.0090 | 0.0149 |
| ud_upos | PRON | context_only | 3 | 0.2895 | 0.0405 | 0.0395 | 0.0405 |
| ud_upos | PROPN | full | 3 | 0.2899 | 0.0192 | 0.0899 | 0.0192 |
| ud_upos | PROPN | word_only | 3 | 0.2539 | 0.0460 | 0.0539 | 0.0460 |
| ud_upos | PROPN | context_only | 3 | 0.2804 | 0.0231 | 0.0804 | 0.0231 |
| ud_upos | PUNCT | full | 3 | 0.2746 | 0.0132 | 0.0746 | 0.0132 |
| ud_upos | PUNCT | word_only | 3 | 0.2318 | 0.0017 | 0.0318 | 0.0017 |
| ud_upos | PUNCT | context_only | 3 | 0.2302 | 0.0104 | 0.0302 | 0.0104 |

Showing 24 of 96 rows; see the linked CSV for the complete table.

**Measured directional contrasts.** Positive values follow the directional prediction named in each contrast (E4 instead records magnitudes without a preferred sign).

| dataset | claim | seeds | value_mean | value_std |
|---|---|---|---|---|
| ud_upos | context_minus_word_Z_readability | 3 | 0.0477 | 0.0146 |
| ud_deprel | context_minus_word_Z_readability | 3 | 0.0497 | 0.0173 |
| ud_discourse | context_minus_word_Z_readability | 3 | 0.2282 | 0.0178 |
| ner_shared | context_minus_word_Z_readability | 3 | 0.1790 | 0.0152 |
| ud_upos | context_Z_above_chance | 3 | 0.0780 | 0.0068 |
| ud_deprel | context_Z_above_chance | 3 | 0.0725 | 0.0034 |
| ud_discourse | context_Z_above_chance | 3 | 0.2744 | 0.0130 |
| ner_shared | context_Z_above_chance | 3 | 0.3488 | 0.0156 |

**Directional claim assessment (descriptive):** 8 dataset/claim contrasts have the predicted positive sign in all three seeds; 0 have the opposite sign in all three seeds; 0 are mixed, tied, or incomplete. Consistent positive signs support the stated directional prediction on this fixed sample; opposite signs contradict that prediction on this sample. These counts are not significance tests or causal conclusions.

![Linear nuisance readability](e3/readability.png)

**Interpretation.** Above-chance balanced accuracy is evidence that a linear readout can recover source/genre conditional on the recorded label. It does not establish that the representation encodes a calibrated posterior over latent state and nuisance. Sparse labels/domains are excluded.

These tables provide diagnostic evidence; support or contradiction of the claimed ordering must be assessed across datasets, seed spread, and reported support counts. A universal causal conclusion is inconclusive from these observational diagnostics alone.

Skipped cells: 219. [Reasons and supports](e3/skips.csv).

## E4: Readout erasure

**Measurement.** A training-only affine erasure removes covariance with within-label centered domain indicators; fresh Y MLPs and Z probes evaluate the result.

Measured datasets: ner_shared, ud_deprel, ud_discourse, ud_upos.

Recorded 12 seed-level conditions. [Scores](e4/scores.csv), [seed summaries](e4/summary.csv).

| dataset | view | seeds | macro_f1_mean | macro_f1_std | f1_drop_mean | f1_drop_std | accuracy_drop_mean | accuracy_drop_std |
|---|---|---|---|---|---|---|---|---|
| ud_upos | erased_full | 3 | 0.6535 | 0.0106 | 0.0014 | 0.0148 | 0.0002 | 0.0033 |
| ud_deprel | erased_full | 3 | 0.3028 | 0.0069 | 0.0222 | 0.0092 | 0.0162 | 0.0036 |
| ud_discourse | erased_full | 3 | 0.0994 | 0.0065 | 0.0995 | 0.0114 | 0.0807 | 0.0086 |
| ner_shared | erased_full | 3 | 0.7871 | 0.0059 | 0.0058 | 0.0010 | 0.0014 | 0.0008 |

**Measured directional contrasts.** Positive values follow the directional prediction named in each contrast (E4 instead records magnitudes without a preferred sign).

| dataset | claim | seeds | value_mean | value_std |
|---|---|---|---|---|
| ud_upos | Y_F1_drop | 3 | 0.0014 | 0.0148 |
| ud_deprel | Y_F1_drop | 3 | 0.0222 | 0.0092 |
| ud_discourse | Y_F1_drop | 3 | 0.0995 | 0.0114 |
| ner_shared | Y_F1_drop | 3 | 0.0058 | 0.0010 |
| ud_upos | remaining_Z_above_chance | 3 | -0.0093 | 0.0110 |
| ud_deprel | remaining_Z_above_chance | 3 | -0.0050 | 0.0171 |
| ud_discourse | remaining_Z_above_chance | 3 | -0.0168 | 0.0102 |
| ner_shared | remaining_Z_above_chance | 3 | 0.0055 | 0.0063 |

**Claim assessment: inconclusive without successful Z removal.** The table quantifies Y loss and remaining conditional readability. Small Y loss together with chance-level Z probes is consistent with separability; larger Y loss is not by itself proof of entanglement.

[Post-erasure Z probes](e4/z_summary.csv) must be considered with the Y drop. [Projection ranks and covariance residuals](e4/erasure.csv).

![Readout erasure](e4/label_drop.png)

**Interpretation.** Y loss is interpretable as a separability diagnostic only together with the post-erasure Z probe. Remaining readability makes the result inconclusive about complete erasure. A large Y loss alone cannot distinguish causal entanglement from loss of useful correlated signal, limited classifier fit, or erasure estimation error.

These tables provide diagnostic evidence; support or contradiction of the claimed ordering must be assessed across datasets, seed spread, and reported support counts. A universal causal conclusion is inconclusive from these observational diagnostics alone.

Skipped cells: 73. [Reasons and supports](e4/skips.csv).

## E5: Within-label dependence

**Measurement.** Unbiased RBF MMD of prediction vectors, document-block permutation p values, per-seed BH q values, and lexical JS; stratified by lexical and predictive entropy.

Measured datasets: ner_shared, ud_deprel, ud_upos.

**No eligible measurements for:** ud_discourse. These datasets are omitted from this experiment's numerical conclusions.

ud_discourse: test domains contain at most 2 documents each; the permutation protocol requires 3. Increasing focal tokens cannot increase independent document support.

Recorded 1765 seed-level conditions. [Scores](e5/scores.csv), [seed summaries](e5/summary.csv).

| dataset | view | label | stratum_kind | stratum | domain_a | domain_b | seeds | mmd_squared_mean | mmd_squared_std | word_js_mean | word_js_std | p_value_mean | p_value_std | q_value_mean | q_value_std |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ud_upos | full | ADJ | all | all | answers | newsgroup | 3 | -0.0049 | 0.0033 | 0.6931 | 0 | 0.4033 | 0.0548 | 0.5796 | 0.0337 |
| ud_upos | full | ADJ | all | all | answers | reviews | 3 | -0.0117 | 0.0014 | 0.6383 | 0 | 0.8800 | 0.0673 | 0.9064 | 0.0472 |
| ud_upos | full | ADJ | all | all | newsgroup | reviews | 3 | 0.0046 | 0.0025 | 0.6390 | 0 | 0.2933 | 0.0448 | 0.4991 | 0.0276 |
| ud_upos | full | ADP | all | all | answers | email | 3 | -0.0036 | 0.0051 | 0.1553 | 0 | 0.3733 | 0.1159 | 0.5559 | 0.0879 |
| ud_upos | full | ADP | all | all | answers | reviews | 3 | -0.0137 | 0.0026 | 0.2192 | 0.0000 | 0.8467 | 0.1002 | 0.8846 | 0.0702 |
| ud_upos | full | ADP | all | all | email | reviews | 3 | 0.0052 | 0.0063 | 0.2034 | 0 | 0.2683 | 0.1221 | 0.4688 | 0.0976 |
| ud_upos | full | ADP | word_entropy | low | answers | email | 3 | -0.0084 | 0.0042 | 0.1433 | 0 | 0.5483 | 0.1056 | 0.6869 | 0.0694 |
| ud_upos | full | ADP | word_entropy | low | answers | reviews | 3 | -0.0149 | 0.0027 | 0.1951 | 0 | 0.7600 | 0.0867 | 0.8263 | 0.0561 |
| ud_upos | full | ADP | word_entropy | low | email | reviews | 3 | 0.0009 | 0.0048 | 0.1792 | 0 | 0.3950 | 0.0900 | 0.5740 | 0.0630 |
| ud_upos | full | ADV | all | all | answers | email | 3 | 0.0037 | 0.0013 | 0.5301 | 0 | 0.3983 | 0.0161 | 0.5728 | 0.0164 |
| ud_upos | full | ADV | all | all | answers | reviews | 3 | -0.0179 | 0.0009 | 0.5542 | 0 | 0.9617 | 0.0208 | 0.9666 | 0.0194 |
| ud_upos | full | ADV | all | all | email | reviews | 3 | 0.0072 | 0.0025 | 0.6163 | 0 | 0.2617 | 0.0225 | 0.4752 | 0.0223 |
| ud_upos | full | ADV | predictive_entropy | high | email | reviews | 2 | 0.0091 | 0.0015 | 0.6931 | 0.0000 | 0.3275 | 0.0106 | 0.5300 | 0.0029 |
| ud_upos | full | AUX | all | all | answers | email | 3 | -0.0043 | 0.0089 | 0.2991 | 0 | 0.4533 | 0.1971 | 0.6124 | 0.1438 |
| ud_upos | full | AUX | all | all | answers | reviews | 3 | 0.0101 | 0.0055 | 0.3675 | 0 | 0.2217 | 0.0690 | 0.4302 | 0.0614 |
| ud_upos | full | AUX | all | all | email | reviews | 3 | -0.0115 | 0.0053 | 0.3666 | 0 | 0.6417 | 0.1683 | 0.7507 | 0.1079 |
| ud_upos | full | AUX | word_entropy | low | answers | email | 3 | -0.0170 | 0.0081 | 0.1999 | 0 | 0.5550 | 0.1600 | 0.6911 | 0.1141 |
| ud_upos | full | AUX | word_entropy | low | answers | reviews | 3 | 0.0238 | 0.0104 | 0.3271 | 0 | 0.1567 | 0.0580 | 0.3615 | 0.0726 |
| ud_upos | full | AUX | word_entropy | low | email | reviews | 3 | -0.0040 | 0.0067 | 0.3203 | 0 | 0.3517 | 0.0874 | 0.5411 | 0.0591 |
| ud_upos | full | DET | all | all | answers | email | 3 | 0.0014 | 0.0036 | 0.2328 | 0.0000 | 0.3550 | 0.0229 | 0.5414 | 0.0110 |
| ud_upos | full | DET | all | all | answers | reviews | 3 | -0.0015 | 0.0041 | 0.1867 | 0 | 0.3967 | 0.0869 | 0.5773 | 0.0706 |
| ud_upos | full | DET | all | all | email | reviews | 3 | 0.0300 | 0.0049 | 0.1597 | 0 | 0.1033 | 0.0176 | 0.2984 | 0.0253 |
| ud_upos | full | DET | word_entropy | low | answers | email | 3 | -0.0184 | 0.0017 | 0.1997 | 0 | 0.7283 | 0.0535 | 0.8045 | 0.0341 |
| ud_upos | full | DET | word_entropy | low | answers | reviews | 3 | 0.0226 | 0.0104 | 0.1518 | 0 | 0.1383 | 0.0530 | 0.3429 | 0.0650 |

Showing 24 of 603 rows; see the linked CSV for the complete table.

**Measured directional contrasts.** Positive values follow the directional prediction named in each contrast (E4 instead records magnitudes without a preferred sign).

| dataset | claim | seeds | value_mean | value_std |
|---|---|---|---|---|
| ud_upos | full_minus_word_MMD | 3 | -0.0189 | 0.0012 |
| ud_deprel | full_minus_word_MMD | 3 | -0.0397 | 0.0044 |
| ner_shared | full_minus_word_MMD | 3 | -0.0328 | 0.0014 |
| ud_upos | context_minus_word_MMD | 3 | -0.0110 | 0.0002 |
| ud_deprel | context_minus_word_MMD | 3 | -0.0273 | 0.0013 |
| ner_shared | context_minus_word_MMD | 3 | -0.0332 | 0.0008 |

**Directional claim assessment (descriptive):** 0 dataset/claim contrasts have the predicted positive sign in all three seeds; 6 have the opposite sign in all three seeds; 0 are mixed, tied, or incomplete. Consistent positive signs support the stated directional prediction on this fixed sample; opposite signs contradict that prediction on this sample. These counts are not significance tests or causal conclusions.

![Within-label dependence](e5/dependence.png)

**Interpretation.** A small q value is evidence of distributional dependence under the block-exchangeability assumption, not a causal diagnosis of Assumption A. Dataset-identity tests use sentence blocks and are exploratory. With 199 permutations, resolution is 0.005; sparse cells and multiple comparisons limit power. Non-rejection is inconclusive, not evidence of invariance. Predictive entropy strata are properties of each fitted model, not measurements of latent ambiguity.

These tables provide diagnostic evidence; support or contradiction of the claimed ordering must be assessed across datasets, seed spread, and reported support counts. A universal causal conclusion is inconclusive from these observational diagnostics alone.

Skipped cells: 296963. [Reasons and supports](e5/skips.csv).

## E6: Cross-domain shift

**Measurement.** Each readout sees only one source domain's training/validation examples; test scores and per-label degradation cover source and eligible target domains.

Measured datasets: ner_shared, ud_deprel, ud_discourse, ud_upos.

Recorded 2511 seed-level conditions. [Scores](e6/scores.csv), [seed summaries](e6/summary.csv).

| dataset | view | source | target | seeds | accuracy_mean | accuracy_std | macro_f1_mean | macro_f1_std | accuracy_drop_mean | accuracy_drop_std | f1_drop_mean | f1_drop_std |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ud_upos | full | answers | answers | 3 | 0.6549 | 0.0056 | 0.5065 | 0.0047 | 0 | 0 | 0 | 0 |
| ud_upos | full | answers | email | 3 | 0.5384 | 0.0011 | 0.4412 | 0.0051 | 0.1165 | 0.0055 | 0.0653 | 0.0088 |
| ud_upos | full | answers | newsgroup | 3 | 0.5677 | 0.0163 | 0.3702 | 0.0168 | 0.0872 | 0.0152 | 0.1363 | 0.0141 |
| ud_upos | full | answers | reviews | 3 | 0.6365 | 0.0095 | 0.4714 | 0.0150 | 0.0184 | 0.0150 | 0.0351 | 0.0195 |
| ud_upos | full | answers | weblog | 3 | 0.6291 | 0.0123 | 0.4546 | 0.0055 | 0.0258 | 0.0179 | 0.0519 | 0.0053 |
| ud_upos | word_only | answers | answers | 3 | 0.6917 | 0.0051 | 0.5670 | 0.0046 | 0 | 0 | 0 | 0 |
| ud_upos | word_only | answers | email | 3 | 0.6415 | 0.0040 | 0.4841 | 0.0066 | 0.0502 | 0.0015 | 0.0829 | 0.0081 |
| ud_upos | word_only | answers | newsgroup | 3 | 0.6784 | 0.0158 | 0.5362 | 0.0100 | 0.0133 | 0.0173 | 0.0308 | 0.0059 |
| ud_upos | word_only | answers | reviews | 3 | 0.6969 | 0.0067 | 0.5579 | 0.0087 | -0.0052 | 0.0116 | 0.0090 | 0.0067 |
| ud_upos | word_only | answers | weblog | 3 | 0.7435 | 0.0142 | 0.5873 | 0.0148 | -0.0518 | 0.0091 | -0.0204 | 0.0177 |
| ud_upos | context_only | answers | answers | 3 | 0.5070 | 0.0013 | 0.3949 | 0.0449 | 0 | 0 | 0 | 0 |
| ud_upos | context_only | answers | email | 3 | 0.4391 | 0.0039 | 0.3542 | 0.0125 | 0.0679 | 0.0050 | 0.0408 | 0.0325 |
| ud_upos | context_only | answers | newsgroup | 3 | 0.4766 | 0.0068 | 0.3384 | 0.0114 | 0.0304 | 0.0075 | 0.0566 | 0.0544 |
| ud_upos | context_only | answers | reviews | 3 | 0.4769 | 0.0067 | 0.3427 | 0.0209 | 0.0301 | 0.0079 | 0.0523 | 0.0260 |
| ud_upos | context_only | answers | weblog | 3 | 0.5458 | 0.0102 | 0.3799 | 0.0129 | -0.0388 | 0.0106 | 0.0151 | 0.0357 |
| ud_upos | full | email | answers | 3 | 0.6409 | 0.0071 | 0.4644 | 0.0207 | 0.1128 | 0.0068 | 0.1304 | 0.0133 |
| ud_upos | full | email | email | 3 | 0.7537 | 0.0011 | 0.5948 | 0.0135 | 0 | 0 | 0 | 0 |
| ud_upos | full | email | newsgroup | 3 | 0.6797 | 0.0117 | 0.5016 | 0.0138 | 0.0740 | 0.0118 | 0.0932 | 0.0266 |
| ud_upos | full | email | reviews | 3 | 0.5810 | 0.0038 | 0.4764 | 0.0009 | 0.1727 | 0.0028 | 0.1184 | 0.0138 |
| ud_upos | full | email | weblog | 3 | 0.7108 | 0.0049 | 0.4864 | 0.0137 | 0.0429 | 0.0050 | 0.1084 | 0.0223 |
| ud_upos | word_only | email | answers | 3 | 0.6667 | 0.0044 | 0.4893 | 0.0022 | 0.0916 | 0.0145 | 0.1470 | 0.0176 |
| ud_upos | word_only | email | email | 3 | 0.7582 | 0.0102 | 0.6363 | 0.0154 | 0 | 0 | 0 | 0 |
| ud_upos | word_only | email | newsgroup | 3 | 0.7122 | 0.0137 | 0.4928 | 0.0091 | 0.0460 | 0.0228 | 0.1435 | 0.0174 |
| ud_upos | word_only | email | reviews | 3 | 0.6205 | 0.0091 | 0.5109 | 0.0047 | 0.1378 | 0.0014 | 0.1254 | 0.0113 |

Showing 24 of 837 rows; see the linked CSV for the complete table.

**Measured directional contrasts.** Positive values follow the directional prediction named in each contrast (E4 instead records magnitudes without a preferred sign).

| dataset | claim | seeds | value_mean | value_std |
|---|---|---|---|---|
| ud_upos | context_minus_full_shift_drop | 3 | -0.0336 | 0.0042 |
| ud_deprel | context_minus_full_shift_drop | 3 | -0.0077 | 0.0041 |
| ud_discourse | context_minus_full_shift_drop | 3 | -0.0020 | 0.0020 |
| ner_shared | context_minus_full_shift_drop | 3 | 0.0056 | 0.0012 |
| ud_upos | full_minus_word_shift_drop | 3 | 0.0268 | 0.0023 |
| ud_deprel | full_minus_word_shift_drop | 3 | 0.0141 | 0.0053 |
| ud_discourse | full_minus_word_shift_drop | 3 | 0.0398 | 0.0039 |
| ner_shared | full_minus_word_shift_drop | 3 | 0.0183 | 0.0012 |

**Directional claim assessment (descriptive):** 5 dataset/claim contrasts have the predicted positive sign in all three seeds; 3 have the opposite sign in all three seeds; 0 are mixed, tied, or incomplete. Consistent positive signs support the stated directional prediction on this fixed sample; opposite signs contradict that prediction on this sample. These counts are not significance tests or causal conclusions.

[Per-label degradation](e6/per_label.csv); [correlation with E5](e6/e5_correlations.csv).

![Cross-domain shift](e6/degradation.png)

**Interpretation.** The ordering of degradation across views is the observable diagnostic. Domains differ in label frequencies, lexical coverage, and (for NER corpora) annotation rules. E5 correlations are descriptive and use a pooled-data classifier; they do not establish that its measured dependence causes the source-only model's degradation.

These tables provide diagnostic evidence; support or contradiction of the claimed ordering must be assessed across datasets, seed spread, and reported support counts. A universal causal conclusion is inconclusive from these observational diagnostics alone.

Skipped cells: 0. [Reasons and supports](e6/skips.csv).

## E7: Mention substitutions

**Measurement.** Training-only same-type, per-word WordPiece-length-matched replacements of a nearby entity or the focal mention; prediction flips and probability L1 changes are paired.

Measured datasets: conll2003, fewnerd.

Recorded 108 seed-level conditions. [Scores](e7/scores.csv), [seed summaries](e7/summary.csv).

| dataset | view | intervention | focal_length | seeds | flip_rate_mean | flip_rate_std | probability_l1_mean | probability_l1_std |
|---|---|---|---|---|---|---|---|---|
| fewnerd | full | neighbor | all | 3 | 0.1178 | 0.0058 | 0.2103 | 0.0034 |
| fewnerd | full | neighbor | single_word | 3 | 0.1333 | 0.0577 | 0.2539 | 0.0079 |
| fewnerd | full | neighbor | multiword | 3 | 0.1139 | 0.0127 | 0.1993 | 0.0049 |
| fewnerd | full | focal | all | 3 | 0.4242 | 0.0048 | 0.7015 | 0.0098 |
| fewnerd | full | focal | single_word | 3 | 0.2436 | 0.0444 | 0.5300 | 0.0064 |
| fewnerd | full | focal | multiword | 3 | 0.4737 | 0.0105 | 0.7485 | 0.0108 |
| fewnerd | word_only | neighbor | all | 3 | 0 | 0 | 0.0067 | 0.0005 |
| fewnerd | word_only | neighbor | single_word | 3 | 0 | 0 | 0.0076 | 0.0003 |
| fewnerd | word_only | neighbor | multiword | 3 | 0 | 0 | 0.0065 | 0.0006 |
| fewnerd | word_only | focal | all | 3 | 0.5950 | 0.0143 | 0.8065 | 0.0348 |
| fewnerd | word_only | focal | single_word | 3 | 0.4487 | 0.0222 | 0.6533 | 0.0465 |
| fewnerd | word_only | focal | multiword | 3 | 0.6351 | 0.0219 | 0.8484 | 0.0316 |
| fewnerd | context_only | neighbor | all | 3 | 0.1313 | 0.0101 | 0.2893 | 0.0179 |
| fewnerd | context_only | neighbor | single_word | 3 | 0.2000 | 0 | 0.4241 | 0.0312 |
| fewnerd | context_only | neighbor | multiword | 3 | 0.1139 | 0.0127 | 0.2551 | 0.0148 |
| fewnerd | context_only | focal | all | 3 | 0.3085 | 0.0208 | 0.5330 | 0.0193 |
| fewnerd | context_only | focal | single_word | 3 | 0 | 0 | 0.0041 | 0.0002 |
| fewnerd | context_only | focal | multiword | 3 | 0.3930 | 0.0265 | 0.6778 | 0.0245 |
| conll2003 | full | neighbor | all | 3 | 0.1746 | 0.0248 | 0.3374 | 0.0146 |
| conll2003 | full | neighbor | single_word | 3 | 0.2403 | 0.0537 | 0.3958 | 0.0118 |
| conll2003 | full | neighbor | multiword | 3 | 0.1057 | 0.0141 | 0.2761 | 0.0176 |
| conll2003 | full | focal | all | 3 | 0.4141 | 0.0156 | 0.7245 | 0.0141 |
| conll2003 | full | focal | single_word | 3 | 0.3472 | 0.0278 | 0.6550 | 0.0130 |
| conll2003 | full | focal | multiword | 3 | 0.5000 | 0 | 0.8140 | 0.0182 |

Showing 24 of 36 rows; see the linked CSV for the complete table.

**Measured directional contrasts.** Positive values follow the directional prediction named in each contrast (E4 instead records magnitudes without a preferred sign).

| dataset | claim | seeds | value_mean | value_std |
|---|---|---|---|---|
| fewnerd | full_minus_word_neighbor_flip_rate | 3 | 0.1178 | 0.0058 |
| conll2003 | full_minus_word_neighbor_flip_rate | 3 | 0.1746 | 0.0248 |

**Directional claim assessment (descriptive):** 2 dataset/claim contrasts have the predicted positive sign in all three seeds; 0 have the opposite sign in all three seeds; 0 are mixed, tied, or incomplete. Consistent positive signs support the stated directional prediction on this fixed sample; opposite signs contradict that prediction on this sample. These counts are not significance tests or causal conclusions.

![Mention substitutions](e7/flips.png)

**Interpretation.** Neighbor-induced flips show sensitivity to a controlled co-occurring mention. Calling the change a nuisance-only intervention additionally requires semantic and label preservation, which this experiment does not prove. Focal substitution changes entity identity; multiword focal mentions can still change visible context under context-only masking. Neighbor substitution should leave word-only input identical under the length/alignment controls.

These tables provide diagnostic evidence; support or contradiction of the claimed ordering must be assessed across datasets, seed spread, and reported support counts. A universal causal conclusion is inconclusive from these observational diagnostics alone.

Skipped cells: 88. [Reasons and supports](e7/skips.csv).

## Scope of the evidence

No selectors or new encoder training are introduced. Baseline code/checkpoints are unchanged. PNG error bars are sample standard deviations over three seed-level means (averaging eligible label/domain cells within a seed where applicable). CSVs preserve the individual cells. Inadequate support is reported as missing measurement; no missing result is treated as support for the framework.
