# Completion and artifact verification

The original baseline grid exited with six successful datasets and two failed dataset loaders (WikiANN and WNUT). The diagnostic suite completed every stage E1–E7 and generated the final report.

- Recomputed the six completed baseline test reports from saved predictions; accuracy, macro F1, span F1 where applicable, and cross-entropy match.
- All 702 diagnostic checkpoints load, have finite weights/predictions, and have ten finite training/validation history rows. Every selected checkpoint matches the best recorded validation criterion.
- Verified all seven paired feature banks, prediction shapes, label ranges, and E1 score tables against saved tensors.
- All diagnostic score-table numeric fields are finite; all seven PNGs decode. E5 adjusted p values reproduce exactly.
- E7 neighbor substitution has zero word-only prediction flips across both NER datasets and all three seeds. Small nonzero probability changes remain; do not interpret changes at that control scale as semantic effects.
- E5 has no eligible GUM measurements: each test genre has two documents, below the protocol minimum of three. This is a data-support limitation, not a failed stage. The report now states this explicitly.

WikiANN now uses its original namespaced repository; WNUT now uses its original Hugging Face parquet conversion. Both repaired loaders were checked successfully for native split sizes and exact label order. The retry grid is `grids/missing_baselines.yaml`; existing successful baseline checkpoints and diagnostic measurements are preserved.

The diagnostic report remains a record of the original six available native datasets plus the shared NER comparison. Repairing the two baselines does not silently add them to that completed diagnostic cohort.

Machine-readable details: [artifact_verification.json](artifact_verification.json). Diagnostic results: [report.md](report.md).
