# Independent-judge uniform-refinement CPU experiment

G and A: frozen bert-base-cased, same BERT encoder family. B: frozen google/electra-base-discriminator, ELECTRA family, new head trained on A's same 105414 original fitting sentences. Head recipe and students unchanged; full-data students, three seeds. One final generated context per trajectory, exact focal pieces and G positions/length retained. Existing uniform finite-pool code is reused, with all final focal vectors cached in addition to accepted ones.

Calibration has one fixed random focal per each of 23593 held-out unique sentences, excluding exact fitted and checkpoint-validation inputs. A errors retained after confidence >=.7. Natural A-only accuracy: 97.120%. A–B agreement: natural 98.244%, accepted generated 74.787%.

| Quantity | Value |
|---|---:|
| Agreed correctness lower, delta=0 | 96.872% |
| Plug-in agreed correctness | 0.9834430535234742 |
| Delta breakdown at 95% | 0.018724 |
| Delta breakdown at 90% | 0.068724 |
| Pass 95% at zero slack | True |
| Pass 90% at zero slack | True |

Certificate is conditional on joint-error transfer, not observed augmentation gold accuracy. Different encoder families do not establish independence of errors. Bonferroni allocations and the mass-box simplex optimization are saved with an independent LP check. If a calibration group has no agreements its error upper bound is one; no probability floors or invented correctness.

| Group | Natural agreed | Wrong agreements | Error upper | Generated agreed |
|---|---:|---:|---:|---:|
| O | 18361 | 197 | 0.01302 | 866 |
| art | 157 | 11 | 0.14566 | 30 |
| building | 148 | 27 | 0.28495 | 0 |
| event | 182 | 21 | 0.19548 | 0 |
| location | 801 | 49 | 0.08840 | 17 |
| organization | 764 | 110 | 0.18240 | 8 |
| other | 216 | 22 | 0.17155 | 0 |
| person | 776 | 41 | 0.07906 | 41 |
| product | 191 | 20 | 0.18032 | 2 |

| Student | Augmented focal examples |
|---|---:|
| baseline | 0 |
| ALL | 20000 |
| FLIP | 1289 |
| AGREED | 964 |

ALL includes every final context, without confidence, source-correctness, text-change or flip filtering. FLIP uses H_a; AGREED adds B=A only after final acceptance. B never guides generation. Variant losses cover focal pseudo-labels only; original labels preserved. Omega=1, mean CE over labelled tokens, proportional mixtures, equal optimizer-step/labelled-token budgets with exact counts in train/budgets.csv. Raw native dev token macro-F1 selects every checkpoint.

| Target | Space | Student | Span F1 mean ± seed SD | Delta pp |
|---|---|---|---:|---:|
| conll2003 | shared_ner | baseline | 70.390 ± 1.411 | +0.000 |
| conll2003 | shared_ner | ALL | 71.281 ± 1.010 | +0.891 |
| conll2003 | shared_ner | FLIP | 70.816 ± 0.541 | +0.426 |
| conll2003 | shared_ner | AGREED | 70.835 ± 1.439 | +0.446 |
| fewnerd | native | baseline | 68.605 ± 0.330 | +0.000 |
| fewnerd | native | ALL | 68.584 ± 0.034 | -0.020 |
| fewnerd | native | FLIP | 68.639 ± 0.188 | +0.034 |
| fewnerd | native | AGREED | 68.705 ± 0.028 | +0.100 |
| fewnerd | shared_ner | baseline | 75.587 ± 0.169 | +0.000 |
| fewnerd | shared_ner | ALL | 75.693 ± 0.073 | +0.106 |
| fewnerd | shared_ner | FLIP | 75.616 ± 0.241 | +0.029 |
| fewnerd | shared_ner | AGREED | 75.659 ± 0.074 | +0.072 |
| wikiann | shared_ner | baseline | 41.389 ± 2.059 | +0.000 |
| wikiann | shared_ner | ALL | 41.947 ± 1.833 | +0.557 |
| wikiann | shared_ner | FLIP | 41.609 ± 0.711 | +0.220 |
| wikiann | shared_ner | AGREED | 41.487 ± 0.246 | +0.098 |
| wnut | shared_ner | baseline | 46.372 ± 1.691 | +0.000 |
| wnut | shared_ner | ALL | 47.267 ± 2.361 | +0.896 |
| wnut | shared_ner | FLIP | 48.857 ± 1.812 | +2.485 |
| wnut | shared_ner | AGREED | 46.579 ± 0.500 | +0.208 |

Per-label seqeval F1/precision/recall: ../test/per_label_per_seed.csv; micro F1: ../test/seqeval_per_seed.csv. Existing shared label mapping is unchanged.

Limitations/deviations:

- The user supplied an explicit arm/filter specification replacing the missing notes reference. Notes were not modified.
- Uniform generation disables intermediate scorer logging: only the final selected context is encoded/scored by A; intermediate score/reward fields are NaN, not inferred or fabricated. Candidate sampling and uniform-selection RNG streams are unchanged.
- H_a includes the established source-correctness check: True. This is recorded explicitly because the prompt abbreviates H_a to final confidence/new-label conditions.
- Known remaining discrepancy with the clarification: anchors are drawn before checking source correctness, which is enforced in FLIP rather than before generation. Consequently ALL includes incorrect-source anchors. The logging-only optimization does not change that sampling policy.
- The number of proposals is 20000, the established small-run budget. Generation anchors are IID uniform-word draws with replacement from the full fit pool, not the previous 2400-sentence student subset. A, B and fresh students now share the full original fit pool as requested; compare to this fresh full-data baseline, not the previous small-data baseline.
- Canonical G word-slot detokenization feeds B. Its own tokenizer may split words differently; nonoverlapping overflow chunks retain all requested word pieces, with mean pooling across pieces. G/A/student focal vectors retain original G input IDs.
- Sentence independence and missing original-document provenance remain flagged; one focal per calibration sentence avoids treating multiple tokens in a sentence as independent. Historical calibration reuse is disclosed in partitions.json. No A/B error-independence assumption is made.
- CPU only, bf16 inference, 16 configured CPU threads. Exact configs/seeds and per-stage timings are saved.
