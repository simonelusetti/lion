# Matched scorer-guided refinement diagnostic

Frozen full-data scorer and MLM; 4,000 original held-out cohort anchors × five replicates per arm. Main guided arm prespecified: **lambda0.01**. Uniform control also scores all nine candidate occurrences. No student training or new annotations.

| Arm | Attempts | Any-flip % | Target % | Any / target % among eligible | Distinct accepted | Anchors with acceptance | Unchanged % | Global duplicate % | Total wall s | Distinct accepted / wall s |
|---|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|
| uniform | 20000 | 6.230 | 1.190 | 6.593 / 1.259 | 1246 | 597 | 0.000 | 0.000 | 1168.951 | 1.066 |
| lambda0.001 | 20000 | 9.605 | 7.395 | 10.164 / 7.825 | 1921 | 1054 | 0.000 | 0.000 | 282.866 | 6.791 |
| lambda0.01 | 20000 | 9.595 | 6.430 | 10.153 / 6.804 | 1919 | 991 | 0.000 | 0.000 | 331.275 | 5.793 |
| lambda0.1 | 20000 | 7.275 | 2.665 | 7.698 / 2.820 | 1455 | 717 | 0.000 | 0.000 | 1044.937 | 1.392 |
| greedy | 20000 | 9.375 | 7.505 | 9.921 / 7.942 | 1875 | 1049 | 0.000 | 0.000 | 791.244 | 2.370 |

All acceptance rates above use all attempts unless explicitly conditional. Distinct accepted identity is exact non-padding token IDs plus focal start/end positions. Reconstruction is separate from duplication.

| Arm | First-replicate attempts | Any-flip % | Target % |
|---|---:|---:|---:|
| uniform | 4000 | 6.100 | 1.000 |
| lambda0.001 | 4000 | 9.225 | 7.075 |
| lambda0.01 | 4000 | 9.775 | 6.475 |
| lambda0.1 | 4000 | 7.000 | 2.350 |
| greedy | 4000 | 9.075 | 7.175 |

| Arm | Target support stratum | Attempts | Any-flip % | Target % |
|---|---|---:|---:|---:|
| uniform | gold_supported_alternative | 15490 | 6.927 | 1.388 |
| uniform | fallback_target | 4510 | 3.836 | 0.510 |
| lambda0.001 | gold_supported_alternative | 15490 | 10.723 | 8.218 |
| lambda0.001 | fallback_target | 4510 | 5.765 | 4.568 |
| lambda0.01 | gold_supported_alternative | 15490 | 10.781 | 7.198 |
| lambda0.01 | fallback_target | 4510 | 5.521 | 3.792 |
| lambda0.1 | gold_supported_alternative | 15490 | 8.205 | 3.060 |
| lambda0.1 | fallback_target | 4510 | 4.080 | 1.308 |
| greedy | gold_supported_alternative | 15490 | 10.536 | 8.386 |
| greedy | fallback_target | 4510 | 5.388 | 4.479 |

| Arm | Eligible | Incorrect source | Final unchanged | Incorrect ∩ unchanged | Stayed source label | Changed below tau | Accepted target | Accepted other | Ever visited original |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| uniform | 18900 | 1100 | 0 | 0 | 15754 | 1900 | 238 | 1008 | 0 |
| lambda0.001 | 18900 | 1100 | 0 | 0 | 14157 | 2822 | 1479 | 442 | 0 |
| lambda0.01 | 18900 | 1100 | 0 | 0 | 14609 | 2372 | 1286 | 633 | 0 |
| lambda0.1 | 18900 | 1100 | 0 | 0 | 15488 | 1957 | 533 | 922 | 0 |
| greedy | 18900 | 1100 | 0 | 0 | 13931 | 3094 | 1501 | 374 | 0 |

Source exclusions and reconstruction overlap; neither is silently dropped from all-attempt rates. The four outcome columns partition eligible final states. Stage visits count initialization and selected editing states, not unselected proposals. Full duplicate accounting and first-replicate/stratum counts are in summary.csv.

| Main guided minus uniform | Difference, pp | Source-sentence-cluster 95% interval, pp |
|---|---:|---|
| any_flip_acceptance | 3.365 | [2.943, 3.799] |
| target_specific_acceptance | 5.240 | [4.846, 5.644] |
| mean_target_probability | 8.973 | [8.600, 9.350] |

| Arm | MLM sequence evaluations | Scorer encoded sequence evaluations | Generation s | Scoring s | Selection s |
|---|---:|---:|---:|---:|---:|
| uniform | 100000 | 740000 | 282.705 | 690.303 | 22.563 |
| lambda0.001 | 100000 | 740000 | 57.805 | 205.516 | 4.586 |
| lambda0.01 | 100000 | 740000 | 70.113 | 232.379 | 5.599 |
| lambda0.1 | 100000 | 740000 | 251.043 | 623.318 | 20.104 |
| greedy | 100000 | 740000 | 186.767 | 484.611 | 14.481 |

The scoring count includes initialization and all nine occurrences in each round, without deduplication. Cached source-vector readouts are additional and recorded in summary.csv. Initialization is physically regenerated and charged to every arm. Equal trajectory counts do not imply equal costs relative to the historical generator.

| Arm | Stage | Mean target p | Predict target % | Target acceptance % | Unchanged transition % |
|---|---:|---:|---:|---:|
| uniform | 0 | 0.043 | 3.585 | 1.165 | — |
| uniform | 1 | 0.042 | 3.760 | 1.125 | 11.380 |
| uniform | 2 | 0.042 | 3.740 | 1.160 | 11.095 |
| uniform | 3 | 0.041 | 3.575 | 1.160 | 11.335 |
| uniform | 4 | 0.041 | 3.725 | 1.190 | 11.110 |
| lambda0.01 | 0 | 0.043 | 3.585 | 1.165 | — |
| lambda0.01 | 1 | 0.071 | 6.725 | 2.385 | 12.130 |
| lambda0.01 | 2 | 0.094 | 9.565 | 3.755 | 14.795 |
| lambda0.01 | 3 | 0.114 | 12.010 | 5.070 | 17.110 |
| lambda0.01 | 4 | 0.131 | 14.265 | 6.430 | 18.305 |

| Positive λ arm | Mean local χ² divergence | Mean effective candidate occurrences |
|---|---:|---:|
| lambda0.001 | 3.112 | 4.944 |
| lambda0.01 | 0.958 | 7.140 |
| lambda0.1 | 0.050 | 8.714 |

The positive-λ solver uses the exact simplex threshold solution in float64, then samples an occurrence. Greedy uses uniform tie breaking. The parent and all duplicate occurrences remain in the candidate distribution; effective candidate counts refer to occurrences, not distinct strings. No intermediate acceptance threshold or best-intermediate/replicate selection is used.

Historical single-completion refinement results and timing are retained in historical_comparison.csv. It is not the matched uniform selection control: it has one completion, no retained-parent candidate and no intermediate reward scoring. Its posthoc target success uses the newly fixed targets.

These are scorer prediction changes, not verified true label changes. The local χ² penalty is relative only to a nine-occurrence uniform distribution; it is not natural-data divergence or a pseudo-label precision certificate. No fluency, grammaticality or plausibility filters/metrics were introduced.

Raw selected states, targets, masks, rewards, selection probabilities, per-step scorer distributions and final trajectory CSVs are saved under results/guided_refinement/.
